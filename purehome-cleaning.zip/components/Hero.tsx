import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center pt-24 pb-20 overflow-hidden wave-bg">
      {/* Playful Shapes */}
      <div className="absolute top-20 right-[5%] w-64 h-64 bg-orange-100 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-pulse"></div>
      <div className="absolute bottom-10 left-[10%] w-96 h-96 bg-teal-50 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-pulse" style={{ animationDelay: '2s' }}></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          
          <div className="w-full lg:w-3/5 space-y-8 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-5 py-2 bg-white border-2 border-orange-100 rounded-full shadow-sm">
              <span className="text-xl">💛</span>
              <span className="text-sm font-black text-orange-500 tracking-wider uppercase font-happy">給媽咪最好的禮物</span>
            </div>

            <h1 className="text-5xl lg:text-8xl font-happy font-black text-slate-900 leading-[1.1]">
              幸福的家，<br />
              從 <span className="text-orange-500">乾乾淨淨</span> 開始
            </h1>
            
            <p className="text-xl lg:text-2xl text-slate-500 font-medium leading-relaxed max-w-2xl">
              辛苦了，親愛的！把繁瑣的家事交給 PureHome，讓 AI 幫您精打細算。把時間留給孩子與自己，享受純淨的生活時刻。
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start pt-4">
              <a 
                href="#quote" 
                className="btn-happy px-10 py-5 bg-orange-500 text-white text-xl shadow-xl shadow-orange-200"
              >
                <span>AI 小助手幫我估價</span>
                <span className="text-2xl">🪄</span>
              </a>
              <a 
                href="#services" 
                className="btn-happy px-10 py-5 bg-white text-slate-700 border-4 border-orange-50 text-xl hover:bg-orange-50"
              >
                找清潔服務
              </a>
            </div>
          </div>

          <div className="w-full lg:w-2/5 relative">
            <div className="relative group">
              {/* Photo Frame Style */}
              <div className="absolute inset-0 bg-yellow-400 rounded-[3rem] rotate-3 -z-10 transition-transform group-hover:rotate-6"></div>
              <div className="bg-white p-4 rounded-[3rem] shadow-2xl border-2 border-white overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1558021211-6d1403321394?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                  alt="Happy Family at Home" 
                  className="w-full h-[500px] object-cover rounded-[2.5rem]"
                />
              </div>
              
              {/* Floating Badge */}
              <div className="absolute -bottom-6 -left-6 bg-teal-400 text-white p-6 rounded-[2rem] shadow-xl rotate-[-5deg] animate-bounce-slow">
                <p className="text-sm font-bold opacity-80">滿意度</p>
                <p className="text-3xl font-black font-happy">100%</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Hero;
import React, { useState, useRef, useEffect } from 'react';
import { generateSmartQuote } from '../services/geminiService';
import { AIQuoteResponse } from '../types';

const AIQuoteGenerator: React.FC = () => {
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<AIQuoteResponse | null>(null);
  const [hasApiKey, setHasApiKey] = useState(false);
  const resultRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const checkKey = async () => {
      const aistudio = (window as any).aistudio;
      if (aistudio) {
        const selected = await aistudio.hasSelectedApiKey();
        setHasApiKey(selected);
      } else {
        setHasApiKey(!!(process.env as any).API_KEY);
      }
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    const aistudio = (window as any).aistudio;
    if (aistudio) {
      try {
        await aistudio.openSelectKey();
        setHasApiKey(true);
      } catch (e) {
        console.error("Failed to select key", e);
      }
    } else {
      alert("此環境不支援自動金鑰設定。請確認環境變數 API_KEY 已設定。");
    }
  };

  const handleGenerate = async () => {
    if (!input.trim()) return;
    
    const aistudio = (window as any).aistudio;
    if (!hasApiKey && aistudio) {
       aistudio.openSelectKey();
       setHasApiKey(true);
       // Proceeding immediately as per guidelines to mitigate race conditions
    }

    setIsLoading(true);
    setResult(null);
    try {
      const data = await generateSmartQuote(input);
      setResult(data);
      setTimeout(() => {
        resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 100);
    } catch (error: any) {
      console.error("Quote Generation Failed:", error);
      if (error.message === 'API_KEY_MISSING') {
         setHasApiKey(false);
         alert("⚠️ 請先點選「啟用小助理」以開始使用。");
      } else {
         alert("⚠️ 喔不！小助理好像感冒了，請再試一次。");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section id="quote" className="py-24 bg-orange-50/50 relative overflow-hidden">
        {/* Background Decorations */}
        <div className="absolute top-0 right-0 p-20 opacity-10 rotate-12">
            <span className="text-9xl">✨</span>
        </div>
        <div className="absolute bottom-0 left-0 p-20 opacity-10 -rotate-12">
            <span className="text-9xl">🏠</span>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl mx-auto text-center mb-16">
            <h2 className="text-4xl lg:text-6xl font-happy font-black text-slate-900 mb-6">
              神奇 <span className="text-orange-500">AI 小助理</span>
            </h2>
            <p className="text-xl text-slate-500 font-medium max-w-2xl mx-auto italic">
              「我家三房兩廳，小孩常在客廳吃零食，廚房油垢有點多...」<br />
              只要輸入您的狀況，AI 幫您算最好的價格。
            </p>
          </div>

          <div className="max-w-3xl mx-auto">
            <div className="bg-white rounded-[3rem] p-4 shadow-2xl border-4 border-orange-100">
              <div className="bg-orange-50 rounded-[2.5rem] p-8 lg:p-10 relative">
                {!hasApiKey ? (
                  <div className="flex flex-col items-center justify-center h-80 text-center space-y-6">
                    <span className="text-7xl animate-bounce">🤖</span>
                    <div>
                      <h3 className="text-2xl font-black text-slate-800 mb-2">準備好讓 AI 幫忙了嗎？</h3>
                      <p className="text-slate-500">請先點擊下方按鈕啟用您的專屬 AI 小助理。</p>
                    </div>
                    <button onClick={handleSelectKey} className="btn-happy px-10 py-5 bg-orange-500 text-white text-xl">
                      啟用 AI 小助理
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="relative">
                      <textarea 
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="請在這裡說說您的家裡狀況..."
                        className="w-full h-40 bg-transparent text-xl text-slate-800 placeholder-slate-400 border-none focus:ring-0 resize-none font-medium leading-relaxed"
                      />
                    </div>
                    <div className="mt-8 flex justify-end">
                      <button 
                        onClick={handleGenerate}
                        disabled={isLoading || !input.trim()}
                        className={`btn-happy px-10 py-4 text-xl
                          ${isLoading || !input.trim() 
                            ? 'bg-slate-200 text-slate-400 cursor-not-allowed' 
                            : 'bg-orange-500 text-white shadow-lg'
                          }`}
                      >
                        {isLoading ? '小助理計算中...' : '看看估價結果 🪄'}
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* AI Result Card */}
            {result && (
              <div ref={resultRef} className="mt-12 animate-fade-in-up">
                <div className="bg-white rounded-[3rem] p-10 shadow-2xl border-2 border-orange-50">
                  <div className="flex flex-col md:flex-row gap-10">
                    <div className="w-full md:w-1/3 bg-orange-50 p-8 rounded-[2rem] text-center border-2 border-orange-100">
                      <p className="text-xs font-black text-orange-400 uppercase tracking-widest mb-4">最適合您的方案</p>
                      <h3 className="text-3xl font-black text-slate-900 mb-6">{result.recommendedPackage}</h3>
                      <div className="space-y-4 mb-8">
                        <div className="bg-white p-4 rounded-2xl shadow-sm">
                           <p className="text-sm font-bold text-slate-400">預估費用</p>
                           <p className="text-3xl font-black text-orange-500">NT$ {result.estimatedPriceRange}</p>
                        </div>
                        <div className="bg-white p-4 rounded-2xl shadow-sm">
                           <p className="text-sm font-bold text-slate-400">預估時間</p>
                           <p className="text-3xl font-black text-slate-900">{result.estimatedHours} 小時</p>
                        </div>
                      </div>
                      <button onClick={() => alert("預約成功！客服將儘速聯絡您。")} className="w-full btn-happy py-4 bg-orange-500 text-white justify-center">
                        立即預約
                      </button>
                    </div>

                    <div className="w-full md:w-2/3 space-y-8">
                      <div>
                        <h4 className="text-2xl font-black text-slate-900 mb-4 flex items-center gap-3">
                          <span className="text-3xl">✨</span> 小助理的分析
                        </h4>
                        <p className="text-slate-500 text-lg leading-relaxed font-medium">
                          {result.reasoning}
                        </p>
                      </div>
                      <div className="pt-6 border-t border-slate-100">
                        <h4 className="text-xl font-black text-slate-900 mb-6">媽咪的小秘訣</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {result.cleaningTips.map((tip, idx) => (
                            <div key={idx} className="bg-teal-50 p-4 rounded-2xl border-2 border-teal-100 text-teal-700 font-bold flex gap-3">
                              <span className="text-xl">✅</span>
                              {tip}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
    </section>
  );
};

export default AIQuoteGenerator;
import React from 'react';
import { SERVICES } from '../constants';

const Services: React.FC = () => {
  const colors = [
    'bg-orange-50 text-orange-600 border-orange-100',
    'bg-teal-50 text-teal-600 border-teal-100',
    'bg-blue-50 text-blue-600 border-blue-100',
    'bg-pink-50 text-pink-600 border-pink-100',
  ];

  return (
    <section id="services" className="py-24 bg-white">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-4xl lg:text-6xl font-happy font-black text-slate-900 mb-6">我們的貼心服務</h2>
        <p className="text-slate-400 text-xl mb-16 max-w-2xl mx-auto">不論是日常打掃還是深層大掃除，我們都有最適合媽咪的方案。</p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {SERVICES.map((service, index) => (
            <div key={service.id} className="bubble-card p-10 flex flex-col items-center text-center group">
              <div className={`w-20 h-20 ${colors[index % 4]} rounded-3xl flex items-center justify-center text-5xl mb-8 group-hover:scale-110 transition-transform duration-300`}>
                {service.icon}
              </div>
              
              <h3 className="text-2xl font-black text-slate-900 mb-4">{service.title}</h3>
              <p className="text-slate-500 mb-8 leading-relaxed font-medium">
                {service.description}
              </p>
              
              <div className="mt-auto w-full pt-6 border-t border-slate-50 flex flex-col items-center">
                <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-1">小資價</p>
                <p className="text-2xl font-black text-orange-500 mb-6">{service.basePrice}</p>
                <a 
                  href="#quote"
                  className="w-full py-3 bg-slate-100 text-slate-700 font-bold rounded-2xl hover:bg-orange-500 hover:text-white transition-all"
                >
                  查看細節
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
import React, { useState, useEffect } from 'react';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: '找服務', href: '#services' },
    { name: 'AI 小助手估價', href: '#quote' },
    { name: '媽咪真心話', href: '#testimonials' },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 flex justify-center pt-4 px-4 pointer-events-none">
      <div 
        className={`pointer-events-auto transition-all duration-500 ease-out 
          ${isScrolled 
            ? 'w-full max-w-5xl bg-white/90 backdrop-blur-md shadow-xl rounded-[2rem] py-3 px-6 border-2 border-orange-50' 
            : 'w-full max-w-7xl bg-transparent py-4 px-6'
          } flex justify-between items-center`}
      >
        {/* Logo */}
        <a href="#" className="flex items-center gap-2 group relative z-50">
          <div className="w-10 h-10 bg-orange-400 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-orange-200 transition-transform group-hover:rotate-6">
             <span className="text-xl">🏠</span>
          </div>
          <span className={`text-xl font-happy font-bold tracking-tight ${isScrolled ? 'text-slate-800' : 'text-slate-900'}`}>
            PureHome
          </span>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-2">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href}
              className="px-5 py-2 text-sm font-bold text-slate-600 hover:text-orange-500 hover:bg-orange-50 rounded-full transition-all"
            >
              {link.name}
            </a>
          ))}
          
          {/* GitHub Link */}
          <a 
            href="https://github.com" 
            target="_blank" 
            rel="noopener noreferrer"
            className="p-2 text-slate-400 hover:text-slate-900 transition-colors"
            title="查看 GitHub 原始碼"
          >
            <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
              <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
            </svg>
          </a>

          <a 
            href="#contact" 
            className="ml-2 px-6 py-2.5 text-sm btn-happy text-white bg-orange-500 hover:bg-orange-600 shadow-md shadow-orange-200"
          >
            預約清潔
          </a>
        </nav>

        {/* Mobile Button */}
        <button 
          className="md:hidden p-2 text-slate-800 bg-white rounded-full shadow-md pointer-events-auto"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" d={isMenuOpen ? "M6 18L18 6M6 6l12 12" : "M3.75 9h16.5m-16.5 6.75h16.5"} />
          </svg>
        </button>

        {/* Mobile Nav */}
        <div className={`fixed inset-0 bg-white z-40 flex flex-col items-center justify-center space-y-8 transition-all duration-300 md:hidden ${isMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}>
          {navLinks.map((link) => (
            <a key={link.name} href={link.href} className="text-2xl font-bold text-slate-800" onClick={() => setIsMenuOpen(false)}>{link.name}</a>
          ))}
          <a href="https://github.com" target="_blank" className="text-xl font-bold text-slate-400">GitHub 專案</a>
          <a href="#contact" className="px-8 py-4 text-xl font-bold text-white bg-orange-500 rounded-full" onClick={() => setIsMenuOpen(false)}>預約清潔</a>
        </div>
      </div>
    </header>
  );
};

export default Header;
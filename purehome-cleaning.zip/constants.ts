import { ServiceItem } from './types';

export const SERVICES: ServiceItem[] = [
  {
    id: 'standard',
    title: '媽媽舒心。日常打掃',
    description: '解放您的雙手，將時間留給心愛的孩子。我們會處理所有的除塵、拖地與廚房表面清潔。',
    icon: '🌸',
    basePrice: 'NT$ 1,200 起',
  },
  {
    id: 'deep',
    title: '全家安心。深層除菌',
    description: '針對家中有過敏兒設計，徹底清除隱藏的塵蟎與頑強水垢，打造健康的遊戲環境。',
    icon: '🧸',
    basePrice: 'NT$ 2,500 起',
  },
  {
    id: 'move',
    title: '快樂新家。空屋清潔',
    description: '準備入住新家了嗎？交給我們將每一吋空間恢復如新，讓全家人開開心心搬新家。',
    icon: '🏠',
    basePrice: 'NT$ 3,000 起',
  },
  {
    id: 'special',
    title: '暖心。客製化服務',
    description: '每位媽媽的需求都不一樣。不管是想針對玩具房還是陽台，AI 會為您算最划算的方案。',
    icon: '🧡',
    basePrice: '小資首選',
  },
];

export const TESTIMONIALS = [
  {
    id: 1,
    name: '林媽媽',
    role: '二寶媽咪',
    content: '以前為了打掃總跟老公吵架，自從把家裡交給 PureHome，生活品質真的提升超多！',
    image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150&q=80',
  },
  {
    id: 2,
    name: '小雅',
    role: '職場新人',
    content: '週末終於可以好好休息了。AI 估價超方便，不用在那邊跟人殺價半天。',
    image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150&q=80',
  },
  {
    id: 3,
    name: '王奶奶',
    role: '最愛乾淨的長輩',
    content: '年輕人很有禮貌，打掃得比我自己弄還乾淨，廚房那個油汙清得亮晶晶。',
    image: 'https://images.unsplash.com/photo-1554151228-14d9def656e4?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150&q=80',
  },
];
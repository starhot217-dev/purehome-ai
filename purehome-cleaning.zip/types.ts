export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  icon: string;
  basePrice: string;
}

export interface QuoteRequest {
  description: string;
}

export interface AIQuoteResponse {
  recommendedPackage: string;
  estimatedPriceRange: string;
  estimatedHours: number;
  reasoning: string;
  cleaningTips: string[];
}

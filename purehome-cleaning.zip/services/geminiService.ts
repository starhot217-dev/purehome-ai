import { GoogleGenAI, Type } from "@google/genai";
import { AIQuoteResponse } from "../types";

export const generateSmartQuote = async (userDescription: string): Promise<AIQuoteResponse> => {
  // IMPORTANT: Initialize the client inside the function to pick up the latest process.env.API_KEY
  // This handles cases where the key is selected by the user after the app has loaded.
  const apiKey = process.env.API_KEY;

  if (!apiKey) {
    console.error("API Key is missing in process.env");
    throw new Error("API_KEY_MISSING");
  }

  const ai = new GoogleGenAI({ apiKey });

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `User cleaning request: "${userDescription}"`,
      config: {
        systemInstruction: `You are a professional cleaning service estimator for "PureHome". 
        Analyze the user's request and provide a structured estimation.
        Services offered: "居家日常清潔" (Standard), "深層大掃除" (Deep), "搬家空屋清潔" (Move-in/out).
        Currency: TWD (NT$).
        Be generous with time estimates to ensure quality.
        Give 2-3 short, practical cleaning tips relevant to their specific situation.`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            recommendedPackage: { type: Type.STRING, description: "The name of the recommended service package" },
            estimatedPriceRange: { type: Type.STRING, description: "Price range in NT$, e.g., '1500 - 2000'" },
            estimatedHours: { type: Type.NUMBER, description: "Estimated hours needed" },
            reasoning: { type: Type.STRING, description: "Why this package and time was chosen, in Traditional Chinese" },
            cleaningTips: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "2-3 helpful cleaning tips related to the request in Traditional Chinese"
            }
          },
          required: ["recommendedPackage", "estimatedPriceRange", "estimatedHours", "reasoning", "cleaningTips"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as AIQuoteResponse;
    }
    
    throw new Error("No response text generated");
  } catch (error) {
    console.error("Gemini API Error Full Details:", error);
    throw error;
  }
};

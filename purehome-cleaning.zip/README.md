# 🏠 PureHome 潔淨之家 - AI 智慧清潔服務

這是一個專為現代家庭打造的智慧清潔預約網站，風格參考了 [Mommy Happy](https://www.mommyhappy.com/)。透過 **Google Gemini 3.0** AI 技術，提供即時、精準的清潔需求評估與估價。

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https%3A%2F%2Fgithub.com%2Fyour-username%2Fyour-repo-name&env=API_KEY&envDescription=Google%20GenAI%20API%20Key&envLink=https%3A%2F%2Faistudio.google.com%2Fapp%2Fapikey)

## ✨ 特色功能

- 🌸 **溫暖居家視覺**：專為媽咪設計的圓潤、活潑、充滿溫度的介面。
- 🪄 **AI 小助理估價**：輸入家裡狀況，AI 自動推薦清潔方案、估算費用與工時。
- 📱 **響應式設計**：完美支援手機與平板，隨時隨地輕鬆預約。
- 🔑 **動態 API 金鑰**：支援 Google AI Studio 金鑰整合，隱私與功能兼具。

## 🚀 快速開始 (GitHub -> Vercel)

1. **Fork 本專案**：將此專案複製到你的 GitHub 帳號。
2. **在 Vercel 中匯入**：
   - 登入 [Vercel](https://vercel.com/)。
   - 點擊 "Add New" -> "Project"。
   - 選擇此 GitHub 專案。
3. **設定環境變數**：
   - 在 Vercel 的部署設定中，點開 **Environment Variables**。
   - 加入一組 Key-Value：
     - **Key**: `API_KEY`
     - **Value**: `你的_GEMINI_API_KEY` (可以在 [Google AI Studio](https://aistudio.google.com/app/apikey) 申請)。
4. **部署**：點擊 "Deploy"，大功告成！

## 🛠 使用技術

- **Frontend**: React (ESM via esm.sh)
- **Styling**: Tailwind CSS
- **AI Engine**: Google Gemini 3.0 Flash
- **Icons**: Lucide & Emoji

## 📄 授權

此專案僅供學習與練習使用。
